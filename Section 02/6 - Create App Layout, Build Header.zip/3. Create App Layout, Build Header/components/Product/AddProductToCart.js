function AddProductToCart() {
  return <>AddProductToCart</>;
}

export default AddProductToCart;
