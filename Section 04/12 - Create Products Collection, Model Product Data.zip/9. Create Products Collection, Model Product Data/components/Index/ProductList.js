function ProductList() {
  return <>ProductList</>;
}

export default ProductList;
