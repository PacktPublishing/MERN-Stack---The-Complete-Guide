function Cart() {
  return <>cart</>;
}

export default Cart;
