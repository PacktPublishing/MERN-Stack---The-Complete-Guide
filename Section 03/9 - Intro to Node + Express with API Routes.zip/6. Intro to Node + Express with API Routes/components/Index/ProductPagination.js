function ProductPagination() {
  return <>ProductPagination</>;
}

export default ProductPagination;
