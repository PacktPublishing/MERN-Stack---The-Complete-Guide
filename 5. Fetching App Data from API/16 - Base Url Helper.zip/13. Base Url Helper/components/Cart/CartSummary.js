function CartSummary() {
  return <>CartSummary</>;
}

export default CartSummary;
